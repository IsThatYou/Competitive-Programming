import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class square_distance {
	StringTokenizer st = new StringTokenizer("");
	BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
	boolean hasNextToken() {
		try {
			while (!st.hasMoreTokens()) {
				String line = input.readLine();
				if (line == null) return false;
				st = new StringTokenizer(line);
			}
		} catch (IOException ex) { throw new RuntimeException(ex); }
		return true;
	}
	String nextToken() {
		return (!hasNextToken()) ? null : st.nextToken();
	}
	int nextInt() {
		return Integer.parseInt(nextToken());
	}
	public static void main(String[] args) {
		new square_distance().run();
	}
	
	static final int MAX = 5000;
	int[][] dist = new int[MAX+1][MAX+1];
	int[] qx = new int[(MAX+1)*(MAX+1)], qy = new int[(MAX+1)*(MAX+1)];
	int qb, qe;
	
	void enqueue(int x, int y, int d) {
		if (x < 0 || x > MAX || y < 0 || y > MAX || dist[x][y] > 0) return;
		dist[x][y] = d;
		qx[qe] = x; qy[qe++] = y;
	}

	void run() {
		int n = nextInt(), q = nextInt();
		qb = qe = 0;
		for (int i = 0; i < n; ++i) enqueue(nextInt(), nextInt(), 1);
		while (qb < qe) {
			int x = qx[qb], y = qy[qb++], d = dist[x][y] + 1;
			enqueue(x-1, y, d); enqueue(x+1, y, d);
			enqueue(x, y-1, d); enqueue(x, y+1, d);
			enqueue(x-1, y-1, d); enqueue(x+1, y-1, d);
			enqueue(x-1, y+1, d); enqueue(x+1, y+1, d);
		}
		for (int i = 0; i < 10; ++i) {
			for (int j = 0; j < 10; ++j) System.err.print(dist[i][j] + " ");
			System.err.println();
		}
		for (int i = 0; i < q; ++i) {
			int x = nextInt(), y = nextInt();
			System.err.println(x + "," + y + " " + dist[x][y]);
			System.out.println(dist[x][y] - 1);
		}
	}
}
