#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;
typedef double ld;

struct Pt{
    int x,y,dist;
};

#define MX 5002
int c[MX][MX];

int main(){
    ll N,Q;cin>>N>>Q;
    vector<Pt> g(N),q(Q);
    for(int x=0; x<MX; ++x){
        for(int y=0; y<MX; ++y){
            c[x][y]=-1;
        }
    }
    for(Pt &p:g){cin>>p.x>>p.y;p.dist=0;}
    for(Pt &p:q){cin>>p.x>>p.y;}
    queue<Pt> que;
    for(Pt p:g){
        que.push(p);
        c[p.x][p.y]=0;
    }
    while(!que.empty()){
        Pt p=que.front();que.pop();
        for(int i=-1;i<=1;++i){
            for(int j=-1;j<=1;++j){
                int dx=p.x+i;
                int dy=p.y+j;
                if(dx>=0 && dy>=0 && dx<MX && dy<MX && c[dx][dy]==-1){
                    c[dx][dy]=p.dist+1;
                    que.push({dx,dy,p.dist+1});
                }
            }
        }
    }
    //for(int x=0; x<MX; ++x){
    //    for(int y=0; y<MX; ++y){
    //        cout<<c[x][y]<<' ';
    //    }
    //    cout<<endl;
    //}
    //cout<<endl;
    
    for(Pt &p:q){
        cout<<c[p.x][p.y]<<endl;
    }
}

