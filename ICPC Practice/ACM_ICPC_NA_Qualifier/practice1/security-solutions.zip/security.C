#include <bits/stdc++.h>
using namespace std;
#define PB push_back
#define ZERO (1e-10)
#define INF int(2e9+1)
#define CL(A,I) (memset(A,I,sizeof(A)))
#define DEB printf("DEB!\n");
#define D(X) cout<<"  "<<#X": "<<X<<endl;
#define EQ(A,B) (A+ZERO>B&&A-ZERO<B)
typedef long long ll;
typedef pair<ll,ll> pll;
typedef vector<int> vi;
typedef pair<int,int> ii;
typedef vector<ii> vii;
#define IN(n) int n;scanf("%d",&n);
#define FOR(i, m, n) for (int i(m); i < n; i++)
#define F(n) FOR(i,0,n)
#define FF(n) FOR(j,0,n)
#define FT(m, n) FOR(k, m, n)
#define aa first
#define bb second
void ga(int N,int *A){F(N)scanf("%d",A+i);}
#define MX 5055
int G[MX][MX],S[MX][MX];
void sum(int N,int M){
    static int H[MX][MX];
    F(N)FF(M)H[i][j]=(i?H[i-1][j]:0)+G[i][j];
    F(N)FF(M)S[i][j]=H[i][j]+(j?S[i][j-1]:0);
}
int sq(int ax,int ay,int bx,int by){
    int W=S[bx][by];
    if(ax)W-=S[ax-1][by];
    if(ay)W-=S[bx][ay-1];
    if(ax&&ay)W+=S[ax-1][ay-1];
    return W;
}
int N,Q,X,Y;
int btw(int r){
    int ax=max(X-r,0),bx=min(X+r,MX-10),ay=max(Y-r,0),by=min(Y+r,MX-10);
    if(ax>bx||ay>by)return 0;
    return sq(ax,ay,bx,by);
}
bool ok(ll t){return btw(t);}
int bs(ll B=0,ll E=INF){
    ll M;
    while(B<E)
        if(ok(M=(B+E)>>1))E=M;
        else B=M+1;
    return B;
}
int main(void){
    scanf("%d%d",&N,&Q);
    F(N)scanf("%d%d",&X,&Y),++G[X+1][Y+1];
    sum(MX-5,MX-5);
    F(Q)scanf("%d%d",&X,&Y),++X,++Y,printf("%d\n",bs(0,1e9+1));
    return 0;
}
